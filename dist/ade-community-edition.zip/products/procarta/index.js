module.exports = require("./adapter");
