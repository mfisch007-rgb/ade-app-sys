/**
 * ADE POCKET OPTION ADAPTER — Binary broker market data via WebSocket
 * and browser automation for web terminal access.
 *
 * Supports: candles, quotes, symbols, account (if authenticated).
 * Execution: PAPER only unless official API verified.
 */

import { MarketDataAdapter } from "../MarketDataAdapter.js";
import { openWebSocket } from "./WebSocketTransport.js";

export class PocketOptionAdapter extends MarketDataAdapter {
  constructor(config = {}) {
    super({
      providerId: "pocket-option",
      providerName: "Pocket Option",
      providerKind: "BINARY_BROKER",
      config: {
        POCKET_OPTION_API_URL: config.POCKET_OPTION_API_URL || process.env.POCKET_OPTION_API_URL,
        POCKET_OPTION_SSID: config.POCKET_OPTION_SSID || process.env.POCKET_OPTION_SSID,
        POCKET_OPTION_DEMO_SSID: config.POCKET_OPTION_DEMO_SSID || process.env.POCKET_OPTION_DEMO_SSID,
        POCKET_OPTION_WS_URL: config.POCKET_OPTION_WS_URL || "wss://api.po.market/socket.io/?EIO=4&transport=websocket",
        ...config
      }
    });
    this.capabilities = {
      data: ["CANDLES", "QUOTES", "SYMBOLS", "TICKS"],
      execution: ["PAPER", "SANDBOX"],
      timeframes: ["M1", "M5", "M15", "M30", "H1"],
      symbols: [],
      authMethods: ["SSID", "BROWSER_SESSION"]
    };
    this._ws = null;
    this._ssid = null;
    this._authConfirmed = false;
    this._candleBuffer = new Map();
  }

  async _doConnect() {
    const creds = this.loadCredentials();
    this._ssid = creds.POCKET_OPTION_SSID || creds.POCKET_OPTION_DEMO_SSID;

    if (this._ssid) {
      const wsOk = await this._connectWebSocket(this._ssid);
      if (wsOk) {
        await this._loadSymbolsViaWS();
        return { authenticated: this._authConfirmed === true };
      }
    }

    // Try browser automation to extract SSID
    const browserSSID = await this._extractSSIDViaBrowser();
    if (browserSSID) {
      this._ssid = browserSSID;
      const wsOk = await this._connectWebSocket(this._ssid);
      if (wsOk) {
        await this._loadSymbolsViaWS();
        return { authenticated: this._authConfirmed === true };
      }
    }

    // Public symbols only
    await this._loadSymbols();
    return { authenticated: false };
  }

  async _connectWebSocket(ssid) {
    const socket = await openWebSocket(this.config.POCKET_OPTION_WS_URL);
    if (!socket) {
      this.state.lastError = "WEBSOCKET_TRANSPORT_UNAVAILABLE";
      return false;
    }
    this._ws = socket;
    this._authConfirmed = false;

    return new Promise((resolve) => {
      let settled = false;
      const finish = (ok) => {
        if (settled) return;
        settled = true;
        resolve(ok === true && socket.readyState === 1);
      };

      socket.on("open", () => {
        // Authenticate with SSID
        socket.send(JSON.stringify(["auth", { ssid }]));
      });

      socket.on("message", (data) => {
        try {
          this._onWSMessage(JSON.parse(data));
        } catch {}
      });

      socket.on("error", () => finish(false));
      socket.on("close", () => { this.state.connection = "DISCONNECTED"; });

      const startedAt = Date.now();
      const poll = setInterval(() => {
        if (this._authConfirmed) {
          clearInterval(poll);
          finish(true);
        } else if (Date.now() - startedAt >= 8000) {
          clearInterval(poll);
          finish(socket.readyState === 1);
        }
      }, 200);

      setTimeout(() => {
        clearInterval(poll);
        finish(socket.readyState === 1);
      }, 10000);
    });
  }

  _onWSMessage(msg) {
    if (!Array.isArray(msg)) return;
    const [event, payload] = msg;

    if (event === "candle" || event === "candles") {
      this._handleCandlePayload(payload);
    } else if (event === "quote" || event === "quotes") {
      this._handleQuotePayload(payload);
    } else if (event === "symbols" || event === "assets") {
      this.capabilities.symbols = (payload || []).map(s => String(s.name || s.symbol || s).toUpperCase()).filter(Boolean);
    } else if (event === "profile" || event === "balance") {
      this._authConfirmed = true;
      this.config._accountInfo = payload;
    } else if (event === "auth" || event === "success" || event === "authorized") {
      this._authConfirmed = true;
    }
  }

  _handleCandlePayload(payload) {
    const candles = Array.isArray(payload) ? payload : [payload];
    for (const c of candles) {
      const key = `${c.symbol || c.asset}|${c.timeframe || c.period}`;
      const buf = this._candleBuffer.get(key) || [];
      buf.push(c);
      if (buf.length > 500) buf.shift();
      this._candleBuffer.set(key, buf);
    }
    this._publish("MARKET_DATA_RECEIVED", { providerId: this.providerId, type: "CANDLES", count: candles.length });
  }

  _handleQuotePayload(payload) {
    const quotes = Array.isArray(payload) ? payload : [payload];
    this._publish("MARKET_DATA_RECEIVED", { providerId: this.providerId, type: "QUOTES", count: quotes.length });
  }

  async _extractSSIDViaBrowser() {
    try {
      await this.initBrowserContext({ headless: true });
      const page = await this.newPage();
      if (!page) return null;

      await page.goto("https://pocketoption.com/en/login/", { waitUntil: "networkidle2", timeout: 30000 });

      // Human-like login (credentials from env)
      const creds = this.loadCredentials();
      if (creds.POCKET_OPTION_EMAIL && creds.POCKET_OPTION_PASSWORD) {
        await this.humanType(page, 'input[name="email"], input[type="email"]', creds.POCKET_OPTION_EMAIL);
        await this.humanType(page, 'input[name="password"], input[type="password"]', creds.POCKET_OPTION_PASSWORD);
        await this.humanClick(page, 'button[type="submit"]');
        await page.waitForNavigation({ waitUntil: "networkidle2", timeout: 30000 }).catch(() => {});
      }

      // Extract SSID from localStorage or cookies
      const ssid = await page.evaluate(() => {
        return localStorage.getItem("ssid") || localStorage.getItem("POCKET_OPTION_SSID") ||
               document.cookie.split("; ").find(c => c.startsWith("ssid="))?.split("=")[1];
      });

      if (ssid) {
        this.config._page = page;
        return ssid;
      }
      return null;
    } catch (err) {
      this.state.lastError = `Browser SSID extraction failed: ${err.message}`;
      return null;
    }
  }

  async _loadSymbolsViaWS() {
    if (this._ws && this._ws.readyState === 1) {
      this._ws.send(JSON.stringify(["getAssets", {}]));
      // Response handled in _onWSMessage
    }
  }

  async _loadSymbols() {
    // Known Pocket Option symbols as fallback
    this.capabilities.symbols = [
      "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "NZDUSD", "USDCHF",
      "EURGBP", "EURJPY", "GBPJPY", "AUDJPY", "CADJPY", "CHFJPY",
      "XAUUSD", "XAGUSD", "BTCUSD", "ETHUSD", "LTCUSD", "XRPUSD",
      "US30", "US100", "US500", "GER30", "UK100", "JPN225"
    ];
  }

  async _doDisconnect() {
    if (this._ws) { this._ws.close(); this._ws = null; }
    await this.closeBrowserContext();
  }

  async _doFetchCandles(symbol, timeframe, limit) {
    const key = `${symbol}|${timeframe}`;
    const buf = this._candleBuffer.get(key) || [];

    if (buf.length) {
      return buf.slice(-limit).map(c => ({
        timestamp: c.time * 1000 || c.timestamp,
        open: c.open, high: c.high, low: c.low, close: c.close,
        volume: c.volume || c.tick_volume
      }));
    }

    // Request via WS
    if (this._ws && this._ws.readyState === 1) {
      this._ws.send(JSON.stringify(["getCandles", { asset: symbol, period: this._tfToSeconds(timeframe), count: limit }]));
      // Wait briefly for response
      await new Promise(r => setTimeout(r, 1000));
      const updated = this._candleBuffer.get(key) || [];
      if (updated.length) return updated.slice(-limit);
    }

    return this._generatePaperCandles(symbol, timeframe, limit);
  }

  _tfToSeconds(tf) { const m = { M1: 60, M5: 300, M15: 900, M30: 1800, H1: 3600 }; return m[tf] || 60; }

  async _doFetchQuotes(symbols) {
    if (this._ws && this._ws.readyState === 1) {
      this._ws.send(JSON.stringify(["subscribeQuotes", { assets: symbols }]));
      await new Promise(r => setTimeout(r, 500));
    }
    return symbols.map(s => ({ symbol: s, bid: 1.1000, ask: 1.1002, dataQuality: "SIMULATED", source: "SIMULATED_PAPER" }));
  }

  liveEligibility() {
    // Reconciliation: consult the operator-configured SSID (config/env) as
    // well as the post-connect session. The prior this._ssid-only check made
    // the canonical Founder verify pre-check fail closed even when SSID env
    // was legitimately configured, dead-ending the verify path.
    const configuredSsid = this._ssid || this.config?.POCKET_OPTION_SSID || this.config?.POCKET_OPTION_DEMO_SSID || process.env.POCKET_OPTION_SSID || process.env.POCKET_OPTION_DEMO_SSID;
    if (configuredSsid) {
      return { eligible: true, mode: "LIVE_IF_APPROVED", venue: this.providerId, note: "SSID configured; live handshake via the Founder verify flow plus explicit human approval per order still required." };
    }
    return { eligible: false, mode: "PAPER_ONLY", reason: "No Pocket Option SSID configured." };
  }

  async executeOrder(order) {
    const elig = this.liveEligibility();
    if (!elig.eligible) {
      return { success: false, mode: "PAPER", reason: elig.reason, order };
    }
    // Fail-closed truthfulness: this adapter transmits no order directly.
    // A VERIFIED venue, entitlement, and explicit per-order human approval via
    // the canonical flow are all required before any live transmission.
    return { success: false, mode: "LIVE_IF_APPROVED", executed: false, order, reason: "No live order transmitted by the adapter. Requires VERIFIED venue, entitlement, and explicit human approval per order." };
  }

  _generatePaperCandles(symbol, timeframe, limit) {
    const base = symbol.includes("JPY") ? 150 : symbol.includes("XAU") ? 2000 : symbol.includes("BTC") ? 50000 : 1.1;
    return Array.from({ length: limit }, (_, i) => {
      const t = Date.now() - (limit - i) * this._tfMs(timeframe);
      const drift = (Math.random() - 0.5) * 0.002;
      const o = base * (1 + drift);
      const h = o * (1 + Math.random() * 0.001);
      const l = o * (1 - Math.random() * 0.001);
      const c = l + Math.random() * (h - l);
      return { timestamp: t, open: o, high: h, low: l, close: c, volume: Math.floor(Math.random() * 1000), dataQuality: "SIMULATED", source: "SIMULATED_PAPER" };
    });
  }

  _tfMs(tf) { const m = { M1: 60000, M5: 300000, M15: 900000, M30: 1800000, H1: 3600000 }; return m[tf] || 60000; }
}

export default PocketOptionAdapter;