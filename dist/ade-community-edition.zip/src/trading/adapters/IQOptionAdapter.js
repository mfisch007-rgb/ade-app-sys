/**
 * ADE IQ OPTION ADAPTER — Binary broker market data via WebSocket API.
 *
 * Supports: candles, quotes, symbols, ticks.
 * Execution: PAPER only unless official API verified.
 */

import crypto from "node:crypto";
import { MarketDataAdapter } from "../MarketDataAdapter.js";
import { openWebSocket } from "./WebSocketTransport.js";

export class IQOptionAdapter extends MarketDataAdapter {
  constructor(config = {}) {
    super({
      providerId: "iq-option",
      providerName: "IQ Option",
      providerKind: "BINARY_BROKER",
      config: {
        IQ_OPTION_API_URL: config.IQ_OPTION_API_URL || process.env.IQ_OPTION_API_URL,
        IQ_OPTION_SSID: config.IQ_OPTION_SSID || process.env.IQ_OPTION_SSID,
        IQ_OPTION_WS_URL: config.IQ_OPTION_WS_URL || "wss://iqoption.com/echo/websocket",
        ...config
      }
    });
    this.capabilities = {
      data: ["CANDLES", "QUOTES", "SYMBOLS", "TICKS"],
      execution: ["PAPER", "SANDBOX"],
      timeframes: ["M1", "M5", "M15", "M30", "H1", "H4"],
      symbols: [],
      authMethods: ["SSID", "BROWSER_SESSION"]
    };
    this._ws = null;
    this._ssid = null;
    this._authConfirmed = false;
    this._candleBuffer = new Map();
  }

  async _doConnect() {
    const creds = this.loadCredentials();
    this._ssid = creds.IQ_OPTION_SSID;

    if (this._ssid) {
      const wsOk = await this._connectWebSocket(this._ssid);
      if (wsOk) {
        await this._loadSymbolsViaWS();
        return { authenticated: this._authConfirmed === true };
      }
    }

    // Try browser automation
    const browserSSID = await this._extractSSIDViaBrowser();
    if (browserSSID) {
      this._ssid = browserSSID;
      const wsOk = await this._connectWebSocket(this._ssid);
      if (wsOk) {
        await this._loadSymbolsViaWS();
        return { authenticated: this._authConfirmed === true };
      }
    }

    await this._loadSymbols();
    return { authenticated: false };
  }

  async _connectWebSocket(ssid) {
    const socket = await openWebSocket(this.config.IQ_OPTION_WS_URL);
    if (!socket) {
      this.state.lastError = "WEBSOCKET_TRANSPORT_UNAVAILABLE";
      return false;
    }
    this._ws = socket;
    this._authConfirmed = false;

    return new Promise((resolve) => {
      let settled = false;
      const finish = (ok) => {
        if (settled) return;
        settled = true;
        resolve(ok === true && socket.readyState === 1);
      };

      socket.on("open", () => {
        socket.send(JSON.stringify({
          name: "ssid",
          msg: ssid,
          request_id: crypto.randomUUID()
        }));
      });

      socket.on("message", (data) => {
        try {
          this._onWSMessage(JSON.parse(data));
        } catch {}
      });

      socket.on("error", () => finish(false));
      socket.on("close", () => { this.state.connection = "DISCONNECTED"; });

      const startedAt = Date.now();
      const poll = setInterval(() => {
        if (this._authConfirmed) {
          clearInterval(poll);
          finish(true);
        } else if (Date.now() - startedAt >= 8000) {
          clearInterval(poll);
          finish(socket.readyState === 1);
        }
      }, 200);

      setTimeout(() => {
        clearInterval(poll);
        finish(socket.readyState === 1);
      }, 10000);
    });
  }

  _onWSMessage(msg) {
    if (msg.name === "candle-generated" || msg.name === "candles") {
      this._handleCandlePayload(msg.msg);
    } else if (msg.name === "quote" || msg.name === "quotes") {
      this._handleQuotePayload(msg.msg);
    } else if (msg.name === "top-assets-updated" || msg.name === "actives") {
      this.capabilities.symbols = Object.values(msg.msg || {})
        .filter(a => a.enabled)
        .map(a => String(a.name || a.symbol).toUpperCase())
        .filter(Boolean);
    } else if (msg.name === "profile" || msg.name === "balance") {
      this._authConfirmed = true;
      this.config._accountInfo = msg.msg;
    } else if (msg.name === "success" || msg.name === "authorization") {
      this._authConfirmed = true;
    }
  }

  _handleCandlePayload(payload) {
    const candles = Array.isArray(payload) ? payload : [payload];
    for (const c of candles) {
      const key = `${c.active || c.symbol}|${c.timeframe || c.size}`;
      const buf = this._candleBuffer.get(key) || [];
      buf.push(c);
      if (buf.length > 500) buf.shift();
      this._candleBuffer.set(key, buf);
    }
    this._publish("MARKET_DATA_RECEIVED", { providerId: this.providerId, type: "CANDLES", count: candles.length });
  }

  _handleQuotePayload(payload) {
    this._publish("MARKET_DATA_RECEIVED", { providerId: this.providerId, type: "QUOTES", count: Array.isArray(payload) ? payload.length : 1 });
  }

  async _extractSSIDViaBrowser() {
    try {
      await this.initBrowserContext({ headless: true });
      const page = await this.newPage();
      if (!page) return null;

      await page.goto("https://iqoption.com/en/login", { waitUntil: "networkidle2", timeout: 30000 });

      const creds = this.loadCredentials();
      if (creds.IQ_OPTION_EMAIL && creds.IQ_OPTION_PASSWORD) {
        await this.humanType(page, 'input[name="email"]', creds.IQ_OPTION_EMAIL);
        await this.humanType(page, 'input[name="password"]', creds.IQ_OPTION_PASSWORD);
        await this.humanClick(page, 'button[type="submit"]');
        await page.waitForNavigation({ waitUntil: "networkidle2", timeout: 30000 }).catch(() => {});
      }

      const ssid = await page.evaluate(() => {
        return localStorage.getItem("ssid") ||
               document.cookie.split("; ").find(c => c.startsWith("ssid="))?.split("=")[1];
      });

      if (ssid) {
        this.config._page = page;
        return ssid;
      }
      return null;
    } catch (err) {
      this.state.lastError = `Browser SSID extraction failed: ${err.message}`;
      return null;
    }
  }

  async _loadSymbolsViaWS() {
    if (this._ws && this._ws.readyState === 1) {
      this._ws.send(JSON.stringify({
        name: "get-top-assets",
        version: "2.0",
        request_id: crypto.randomUUID()
      }));
    }
  }

  async _loadSymbols() {
    this.capabilities.symbols = [
      "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "NZDUSD",
      "EURGBP", "EURJPY", "GBPJPY", "AUDJPY", "CADJPY",
      "XAUUSD", "XAGUSD", "BTCUSD", "ETHUSD", "LTCUSD",
      "SPX500", "NAS100", "GER30", "UK100"
    ];
  }

  async _doDisconnect() {
    if (this._ws) { this._ws.close(); this._ws = null; }
    await this.closeBrowserContext();
  }

  async _doFetchCandles(symbol, timeframe, limit) {
    const key = `${symbol}|${timeframe}`;
    const buf = this._candleBuffer.get(key) || [];

    if (buf.length) {
      return buf.slice(-limit).map(c => ({
        timestamp: c.from * 1000,
        open: c.open, high: c.max, low: c.min, close: c.close,
        volume: c.volume
      }));
    }

    if (this._ws && this._ws.readyState === 1) {
      this._ws.send(JSON.stringify({
        name: "get-candles",
        version: "2.0",
        msg: { active: symbol, size: this._tfToSeconds(timeframe), to: Math.floor(Date.now()/1000), count: limit },
        request_id: crypto.randomUUID()
      }));
      await new Promise(r => setTimeout(r, 1000));
      const updated = this._candleBuffer.get(key) || [];
      if (updated.length) return updated.slice(-limit);
    }

    return this._generatePaperCandles(symbol, timeframe, limit);
  }

  _tfToSeconds(tf) { const m = { M1: 60, M5: 300, M15: 900, M30: 1800, H1: 3600, H4: 14400 }; return m[tf] || 60; }

  async _doFetchQuotes(symbols) {
    if (this._ws && this._ws.readyState === 1) {
      for (const s of symbols) {
        this._ws.send(JSON.stringify({
          name: "subscribe-quote",
          msg: { active: s },
          request_id: crypto.randomUUID()
        }));
      }
      await new Promise(r => setTimeout(r, 500));
    }
    return symbols.map(s => ({ symbol: s, bid: 1.1000, ask: 1.1002, dataQuality: "SIMULATED", source: "SIMULATED_PAPER" }));
  }

  liveEligibility() {
    // Reconciliation: consult the operator-configured SSID (config/env) as
    // well as the post-connect session. The prior this._ssid-only check made
    // the canonical Founder verify pre-check fail closed even when SSID env
    // was legitimately configured, dead-ending the verify path.
    const configuredSsid = this._ssid || this.config?.IQ_OPTION_SSID || process.env.IQ_OPTION_SSID;
    if (configuredSsid) {
      return { eligible: true, mode: "LIVE_IF_APPROVED", venue: this.providerId, note: "SSID configured; live handshake via the Founder verify flow plus explicit human approval per order still required." };
    }
    return { eligible: false, mode: "PAPER_ONLY", reason: "No IQ Option SSID configured." };
  }

  async executeOrder(order) {
    const elig = this.liveEligibility();
    if (!elig.eligible) {
      return { success: false, mode: "PAPER", reason: elig.reason, order };
    }
    // Fail-closed truthfulness: this adapter transmits no order directly.
    // A VERIFIED venue, entitlement, and explicit per-order human approval via
    // the canonical flow are all required before any live transmission.
    return { success: false, mode: "LIVE_IF_APPROVED", executed: false, order, reason: "No live order transmitted by the adapter. Requires VERIFIED venue, entitlement, and explicit human approval per order." };
  }

  _generatePaperCandles(symbol, timeframe, limit) {
    const base = symbol.includes("JPY") ? 150 : symbol.includes("XAU") ? 2000 : symbol.includes("BTC") ? 50000 : 1.1;
    return Array.from({ length: limit }, (_, i) => {
      const t = Date.now() - (limit - i) * this._tfMs(timeframe);
      const drift = (Math.random() - 0.5) * 0.002;
      const o = base * (1 + drift);
      const h = o * (1 + Math.random() * 0.001);
      const l = o * (1 - Math.random() * 0.001);
      const c = l + Math.random() * (h - l);
      return { timestamp: t, open: o, high: h, low: l, close: c, volume: Math.floor(Math.random() * 1000), dataQuality: "SIMULATED", source: "SIMULATED_PAPER" };
    });
  }

  _tfMs(tf) { const m = { M1: 60000, M5: 300000, M15: 900000, M30: 1800000, H1: 3600000, H4: 14400000 }; return m[tf] || 60000; }
}

export default IQOptionAdapter;